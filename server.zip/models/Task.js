const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Task title is required'],
      trim: true,
      maxlength: [300, 'Task title is too long (max 300 characters)'],
    },
    // Restored: the AI task-extraction flow (renderer.js -> 'save-task')
    // sends this field. Without it, Mongoose silently drops it.
    date: {
      type: String,
      default: 'Not set',
      trim: true,
    },
    urgency: {
      type: String,
      enum: {
        values: ['Normal', 'Medium', 'High', 'Urgent'],
        message: '{VALUE} is not a valid urgency level',
      },
      default: 'Normal',
    },
    status: {
      type: String,
      enum: {
        values: ['open', 'completed'],
        message: '{VALUE} is not a valid status',
      },
      default: 'open',
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Task', taskSchema);
