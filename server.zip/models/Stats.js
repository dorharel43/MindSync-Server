const mongoose = require('mongoose');

// Singleton: one stats document tracks XP/level/streak.
const statsSchema = new mongoose.Schema(
  {
    xp: { type: Number, default: 0, min: 0 },
    level: { type: Number, default: 1, min: 1 },
    streak: { type: Number, default: 0, min: 0 },
    lastTaskDate: { type: String, default: null },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Stats', statsSchema);
