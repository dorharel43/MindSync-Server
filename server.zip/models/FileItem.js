const mongoose = require('mongoose');

const fileItemSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'File name is required'],
      trim: true,
    },
    content: {
      type: String,
      default: '',
    },
    // Stored as the folder's *name* (matches the client: uploadFolderSelect.value).
    // "No Folder" is the unfiled bucket.
    folder: {
      type: String,
      default: 'No Folder',
      trim: true,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('FileItem', fileItemSchema);
