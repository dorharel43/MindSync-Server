const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Event title is required'],
      trim: true,
      maxlength: [300, 'Event title is too long (max 300 characters)'],
    },
    day: {
      type: String,
      required: [true, 'Event day is required'],
      enum: {
        values: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
        message: '{VALUE} is not a valid day',
      },
    },
    time: {
      type: String,
      required: [true, 'Event time is required'],
      match: [/^([01]\d|2[0-3]):([0-5]\d)$/, 'Time must be in HH:MM 24-hour format'],
    },
    type: {
      type: String,
      enum: {
        values: ['lesson', 'exam', 'study', 'personal'],
        message: '{VALUE} is not a valid event type',
      },
      default: 'personal',
    },
    // Set when mirrored into Google Calendar. That OAuth flow stays in the
    // Electron main process (it owns the token), not in this server.
    googleEventId: {
      type: String,
      default: null,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Event', eventSchema);
