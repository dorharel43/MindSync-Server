require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const { notFound, errorHandler } = require('./middleware/errorHandler');

// ==========================================
// Startup env validation - fail fast and loud
// instead of limping along with an undefined MONGO_URI.
// ==========================================
const REQUIRED_ENV_VARS = ['MONGO_URI'];
const missingEnvVars = REQUIRED_ENV_VARS.filter((key) => !process.env[key]);
if (missingEnvVars.length > 0) {
  console.error(`❌ Missing required environment variable(s): ${missingEnvVars.join(', ')}`);
  console.error('   Create a .env file (see .env.example) before starting the server.');
  process.exit(1);
}

const app = express();
const PORT = process.env.PORT || 5000;

// ==========================================
// Middlewares
// ==========================================
app.use(cors());
app.use(express.json({ limit: '10mb' })); // 10mb headroom for pasted file/study-material content

// ==========================================
// DB connection - with resilience for a long-running server
// ==========================================
mongoose.set('strictQuery', true);

async function connectDB() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ Connected to MongoDB Atlas!');
  } catch (err) {
    console.error('❌ MongoDB connection error:', err.message);
    process.exit(1); // no point serving requests we can't fulfill
  }
}
connectDB();

mongoose.connection.on('error', (err) => console.error('❌ MongoDB runtime error:', err.message));
mongoose.connection.on('disconnected', () => console.warn('⚠️  MongoDB disconnected. Mongoose will retry automatically.'));
mongoose.connection.on('reconnected', () => console.log('✅ MongoDB reconnected.'));

// ==========================================
// Health check - useful for the Electron client to know the black box is up
// ==========================================
app.get('/', (req, res) => {
  res.json({
    status: 'ok',
    service: 'MindSync Server',
    dbState: mongoose.connection.readyState, // 1 = connected
  });
});

// ==========================================
// Routes
// ==========================================
app.use('/api/tasks', require('./routes/tasks'));
app.use('/api/events', require('./routes/events'));
app.use('/api/folders', require('./routes/folders'));
app.use('/api/files', require('./routes/files'));
app.use('/api/profile', require('./routes/profile'));
app.use('/api/stats', require('./routes/Stats'));
app.use('/api/settings', require('./routes/settings'));
app.use('/api/admin', require('./routes/admin'));

// ==========================================
// Error handling - must be registered last, in this order
// ==========================================
app.use(notFound);
app.use(errorHandler);

// ==========================================
// Process-level safety nets
// ==========================================
process.on('unhandledRejection', (reason) => {
  console.error('❌ Unhandled promise rejection:', reason);
});
process.on('uncaughtException', (err) => {
  console.error('❌ Uncaught exception:', err);
  process.exit(1); // process is in an unknown state - restart cleanly (use nodemon/pm2)
});

app.listen(PORT, () => {
  console.log(`🚀 Server is running on http://localhost:${PORT}`);
});

module.exports = app; // exported for future test suites (supertest, etc.)