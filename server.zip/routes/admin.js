const express = require('express');
const router = express.Router();
const Task = require('../models/Task');
const Event = require('../models/Event');
const Folder = require('../models/Folder');
const FileItem = require('../models/FileItem');
const Stats = require('../models/Stats');
const asyncHandler = require('../middleware/asyncHandler');

// POST /api/admin/hard-reset - wipes everything except profile/settings.
router.post(
  '/hard-reset',
  asyncHandler(async (req, res) => {
    await Promise.all([Task.deleteMany({}), Event.deleteMany({}), Folder.deleteMany({}), FileItem.deleteMany({})]);
    await Stats.deleteMany({}); // getSingleton() recreates with defaults on next read
    res.json({ success: true });
  })
);

module.exports = router;
