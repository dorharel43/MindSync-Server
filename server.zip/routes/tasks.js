const express = require('express');
const router = express.Router();
const Task = require('../models/Task');
const asyncHandler = require('../middleware/asyncHandler');
const ApiError = require('../middleware/ApiError');

// GET /api/tasks - list all, newest first. ?status=open|completed to filter.
router.get(
  '/',
  asyncHandler(async (req, res) => {
    const filter = req.query.status ? { status: req.query.status } : {};
    const tasks = await Task.find(filter).sort({ createdAt: -1 });
    res.json(tasks);
  })
);

// GET /api/tasks/:id
router.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const task = await Task.findById(req.params.id);
    if (!task) throw new ApiError(404, 'Task not found');
    res.json(task);
  })
);

// POST /api/tasks - create
router.post(
  '/',
  asyncHandler(async (req, res) => {
    const { title, date, urgency } = req.body;
    const task = await Task.create({ title, date, urgency });
    res.status(201).json(task);
  })
);

// PUT /api/tasks/:id - update (edit title/date/urgency, or mark completed)
router.put(
  '/:id',
  asyncHandler(async (req, res) => {
    const { title, date, urgency, status } = req.body;
    const task = await Task.findByIdAndUpdate(
      req.params.id,
      { title, date, urgency, status },
      { new: true, runValidators: true, omitUndefined: true }
    );
    if (!task) throw new ApiError(404, 'Task not found');
    res.json(task);
  })
);

// DELETE /api/tasks/:id
router.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    const task = await Task.findByIdAndDelete(req.params.id);
    if (!task) throw new ApiError(404, 'Task not found');
    res.json({ success: true, deletedId: req.params.id });
  })
);

module.exports = router;
