const express = require('express');
const router = express.Router();
const Stats = require('../models/Stats');
const asyncHandler = require('../middleware/asyncHandler');
const { getSingleton } = require('../utils/singleton');

const XP_BY_URGENCY = { Normal: 50, Medium: 75, High: 100, Urgent: 150 };

// GET /api/stats
router.get(
  '/',
  asyncHandler(async (req, res) => {
    const stats = await getSingleton(Stats);
    res.json(stats);
  })
);

// POST /api/stats/complete-task  { urgency }
router.post(
  '/complete-task',
  asyncHandler(async (req, res) => {
    const urgency = req.body.urgency || 'Normal';
    const stats = await getSingleton(Stats);

    const today = new Date().toDateString();
    if (stats.lastTaskDate) {
      const diffDays = Math.ceil(
        Math.abs(new Date(today) - new Date(stats.lastTaskDate)) / (1000 * 60 * 60 * 24)
      );
      if (diffDays === 1) {
        if (stats.streak < 10) stats.streak += 1;
      } else if (diffDays > 1) {
        stats.streak = 0;
      }
    } else {
      stats.streak = 0;
    }

    stats.lastTaskDate = today;
    const baseXP = XP_BY_URGENCY[urgency] ?? XP_BY_URGENCY.Normal;
    const addedXP = Math.round(baseXP * (1 + stats.streak * 0.1));
    stats.xp += addedXP;
    stats.level = Math.floor(stats.xp / 1000) + 1;

    await stats.save();
    res.json({ stats, addedXP });
  })
);

// POST /api/stats/reset
router.post(
  '/reset',
  asyncHandler(async (req, res) => {
    const stats = await getSingleton(Stats);
    stats.xp = 0;
    stats.level = 1;
    stats.streak = 0;
    stats.lastTaskDate = null;
    await stats.save();
    res.json(stats);
  })
);

module.exports = router;
